package com.fortytwo.entities;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.github.fluent.hibernate.cfg.scanner.EntityScanner;

public class SessionUtil {

    private static SessionUtil instance=new SessionUtil();
    private SessionFactory sessionFactory;
    
    public static SessionUtil getInstance(){
            return instance;
    }
    
    public SessionUtil(){
    	
    	try
    	{   
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
      
        EntityScanner.scanPackages("com.fortytwo.entities").addTo(configuration);
        //  configuration.addPackage("com.fortytwo.models");
        ServiceRegistry srvcReg = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        sessionFactory = configuration.buildSessionFactory(srvcReg);    
        
        //System.out.println(configuration.getProperties());
       	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public static Session getSession(){
        Session session =  getInstance().sessionFactory.openSession();
        
        return session;
    }
}
