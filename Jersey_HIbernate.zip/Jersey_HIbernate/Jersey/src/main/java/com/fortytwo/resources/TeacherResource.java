package com.fortytwo.resources;


import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.fortytwo.entities.Teacher;
import com.fortytwo.service.TeacherService;


@Path("/teachers")
public class TeacherResource {
	
	TeacherService teacherService=new TeacherService();
	
	@POST
	@Path("create")
	@Consumes("application/json")
	public Response addTeacher(Teacher teacher)
	{
		teacherService.addTeacher(teacher);
		return Response.ok().build();	
	}
	
	
	@PUT
	@Path("update")
	@Consumes("application/json")
	public Response updateTeacher(Teacher teacher)
	{
		teacherService.updateTeacher(teacher);
		return Response.ok().build();	
	}

	
}