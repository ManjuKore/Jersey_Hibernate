package com.fortytwo.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="subject")
public class Subject {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int subid;
	
	@Column
	private String subjectname;

	@ManyToMany(mappedBy="subjects",cascade = CascadeType.ALL)
	private Set<Student> students;
	

	@ManyToMany(mappedBy="subject",cascade = CascadeType.ALL)
	private Set<Teacher> teachers;



	public int getSubid() {
		return subid;
	}


	public void setSubid(int subid) {
		this.subid = subid;
	}

	public String getSubjectname() {
		return subjectname;
	}


	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	public Set<Student> getStudents() {
		return students;
	}


	public void setStudents(Set<Student> students) {
		this.students = students;
	}


	public Set<Teacher> getTeachers() {
		return teachers;
	}


	public void setTeachers(Set<Teacher> teachers) {
		this.teachers = teachers;
	}	
	

	@Override
	public String toString() {
		return "Subject [subid=" + subid + ", subjectname=" + subjectname + ", students=" + students + ", teachers="
				+ teachers + "]";
	}

}

