package com.fortytwo.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.fortytwo.entities.SessionUtil;
import com.fortytwo.entities.Subject;

public class SubjectService {
	
	SessionUtil sessionUtil;
	
	public SubjectService()
	{
		sessionUtil=new SessionUtil();
	}
	
	public void addSubject(Subject subject) {
		// TODO Auto-generated method stub
		Session session=SessionUtil.getSession();
		Transaction tx= session.beginTransaction();
		session.save(subject);	
		tx.commit();
		session.close();		
	}

	public void updateSubject(Subject subject) {
		// TODO Auto-generated method stub
	
			Session session=SessionUtil.getSession();
			if(session!=null && subject.getSubid()>=0)
			{
				Transaction tx= session.beginTransaction();
				Subject subjectobj=session.get(Subject.class, subject.getSubid());
				subjectobj.setTeachers(subject.getTeachers());
				session.saveOrUpdate(subject);	
				tx.commit();
				session.close();
			}	
	}

}
