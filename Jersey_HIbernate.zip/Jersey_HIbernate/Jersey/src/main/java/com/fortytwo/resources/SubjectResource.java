package com.fortytwo.resources;


import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.fortytwo.entities.Subject;
import com.fortytwo.service.SubjectService;

@Path("/subjects")
public class SubjectResource {
	
	SubjectService subjectService=new SubjectService();
	
	@POST
	@Path("create")
	@Consumes("application/json")
	public Response addSubject(Subject subject)
	{
		subjectService.addSubject(subject);		
		return Response.ok().build();	
	}
	
	  @PUT
	  @Path("update")	  
	  @Produces("application/json") 
	  public Response updateSubject(Subject subject) 
	  {
		  subjectService.updateSubject(subject); 
		  return Response.ok().build(); 
	  }


}
