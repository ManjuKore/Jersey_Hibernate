package com.fortytwo.service;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.fortytwo.entities.SessionUtil;
import com.fortytwo.entities.Student;

public class StudentService {
	
	
	SessionUtil sessionUtil;
	public StudentService()
	{
		 sessionUtil=new SessionUtil(); 
	}

	
	public void addStudent(Student student) {
		
		Session session=SessionUtil.getSession();
		if(session!=null)
		{
		Transaction tx= session.beginTransaction();
		
		session.save(student);
		
		tx.commit();
		session.close();
		}
		
	}

	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		
		Session session=SessionUtil.getSession();
		if(session!=null && student.getSid()>=0)
		{
			Transaction tx= session.beginTransaction();
			Student studentobj=session.get(Student.class,student.getSid());
			studentobj.setSubjects(student.getSubjects());
			session.saveOrUpdate(student);	
			tx.commit();
			session.close();
		}
		
	}
	
	
	 public void deleteStudent(int id) 
	 { 
		 if(id>=0)
		 {
		 Session session = SessionUtil.getSession(); 
		 Transaction tx = session.beginTransaction();
		 Query query=session.createQuery("delete from student where sid=:id");
		 query.setInteger("sid",id);
		 
		 //session.delete(session.get(Student.class, id));
		 tx.commit(); 
		 session.close();
		 }
	 }
	 

}
