package com.fortytwo.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.fortytwo.entities.SessionUtil;
import com.fortytwo.entities.Teacher;

public class TeacherService {
	
	public void addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		Session session=SessionUtil.getSession();
		Transaction tx= session.beginTransaction();
		session.save(teacher);
		tx.commit();
		session.close();
	}

	public void updateTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		Session session=SessionUtil.getSession();
		if(session!=null && teacher.getTeacherid()>=0)
		{
			Transaction tx= session.beginTransaction();
			Teacher teacherobj=session.get(Teacher.class, teacher.getTeacherid());
			teacherobj.setSubject(teacher.getSubject());
			session.saveOrUpdate(teacher);
			tx.commit();
			session.close();
		}
	}
}
